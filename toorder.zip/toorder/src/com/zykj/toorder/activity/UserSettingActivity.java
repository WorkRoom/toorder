package com.zykj.toorder.activity;

import android.os.Bundle;

import com.zykj.toorder.BaseActivity;
import com.zykj.toorder.R;
import com.zykj.toorder.view.MyCommonTitle;

public class UserSettingActivity extends BaseActivity{
	MyCommonTitle myCommonTitle;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_more_user_setting);
		
		initView();
	}
	private void initView() {
		myCommonTitle=(MyCommonTitle) findViewById(R.id.aci_myTitle);
		myCommonTitle.setTitle("个人设置");
		myCommonTitle.setEditTitle("保存");
		myCommonTitle.setBackEditTitle("更多");
	}

}
