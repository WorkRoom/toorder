/**
 * 
 */
package com.zykj.toorder.activity;

import android.os.Bundle;

import com.zykj.toorder.BaseActivity;


public class AdminDetailsActivity extends BaseActivity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

}
