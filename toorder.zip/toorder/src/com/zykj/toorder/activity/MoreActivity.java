package com.zykj.toorder.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.zykj.toorder.BaseActivity;
import com.zykj.toorder.R;
import com.zykj.toorder.view.MyCommonTitle;

public class MoreActivity extends BaseActivity {
	MyCommonTitle myCommonTitle;
	LinearLayout user_setting, change_pass, manage_address, permission_setting,
			push_message;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_more);

		initView();

	}

	private void initView() {
		myCommonTitle=(MyCommonTitle) findViewById(R.id.aci_myTitle);
		myCommonTitle.setTitle("更多");
		user_setting = (LinearLayout) findViewById(R.id.app_user_setting);
		change_pass = (LinearLayout) findViewById(R.id.app_change_pass);
		manage_address = (LinearLayout) findViewById(R.id.app_manage_address);
		permission_setting = (LinearLayout) findViewById(R.id.app_permission_setting);
		push_message = (LinearLayout) findViewById(R.id.app_push_message);

		setListener(user_setting, change_pass, manage_address,
				permission_setting, push_message);
	}

	@Override
	public void onClick(View view) {

		switch (view.getId()) {
		case R.id.app_user_setting:
			
			startActivity(new Intent(MoreActivity.this, UserSettingActivity.class));

			break;
		case R.id.app_change_pass:
			startActivity(new Intent(MoreActivity.this, ChangePassActivity.class));
			break;
		case R.id.app_manage_address:

			break;
		case R.id.app_permission_setting:

			break;
		case R.id.app_push_message:

			break;

		default:
			break;
		}
	}

}
