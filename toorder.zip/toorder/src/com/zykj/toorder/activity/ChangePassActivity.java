package com.zykj.toorder.activity;

import android.os.Bundle;
import android.widget.TextView;

import com.zykj.toorder.BaseActivity;
import com.zykj.toorder.R;
import com.zykj.toorder.view.MyCommonTitle;

public class ChangePassActivity extends BaseActivity {

	MyCommonTitle myCommonTitle;
	private TextView newPass,confirmPass;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_more_change_pass);
		initView();
		}

	private void initView() {
		myCommonTitle=(MyCommonTitle) findViewById(R.id.aci_mytitle);
		myCommonTitle.setTitle("密码修改");
		myCommonTitle.setEditTitle("保存");
		myCommonTitle.setBackEditTitle("更多");
		newPass=(TextView) findViewById(R.id.new_pass);
		confirmPass=(TextView) findViewById(R.id.confirm_pass);
	}

}
